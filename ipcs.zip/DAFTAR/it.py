@bayu_joo
kancotdiq Menambahkan file melalui unggahan
 1 kontributor
54 baris (46 sloc)  1,81 KB
 
#Jangan ganti penulis, hargai pembuat tanjung loh buat nya

 permintaan impor , os , re

b = " \ 033 [0; 34m"
g = " \ 033 [1; 32m"
w = " \ 033 [1; 37m"
r = " \ 033 [1; 31m"
y = " \ 033 [1; 33m"
cyan  =  " \ 033 [0; 36m"
lgray  =  " \ 033 [0; 37m"
dgray  =  " \ 033 [1; 30m"
ir  =  " \ 033 [0; 101m"
reset  =  " \ 033 [0m"


headers  = { 'User-Agent' : 'Mozilla / 5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit / 537.36 (KHTML, seperti Gecko) Chrome / 39.0.2171.95 Safari / 537.36' }



def  italy ():
     halaman global
    res  =  permintaan . dapatkan ( 'https://www.insecam.org/en/bycountry/IT/' , headers = headers )
    findpage  =  re . findAll ( ' "? page =", \ s \ d +' , res . teks ) [ 1 ]
    rfindpage  =  halaman pencarian . ganti ( 'page = ",' , '' )
    os . sistem ( 'jelas' )
    cetak ( "{} ____" ). format ( r )
    cetak ( "_ [] _ ​​/ ____ \ __ n_" )
    cetak ( "| _____. - .__ () _ |" )
    cetak ( "| Saya // # \\ \ |" )
    cetak ( "{} | P    \\ \ __ // |" ). format ( w )
    cetak ( "| CS '-' |" )
    cetak ( "{} '--------------'---------- {} ----------------- -. " ). format ( r , w )
    cetak ( "{} | {} Penulis: {} HVmbl3 {} | {} INDO {} N {} {} ESIA |" ). format ( r , w , r , w , r , ir , reset , w )
    cetak ( "{} | {} Youtube: {} Shodiq 2701 {} | {} + 62-813-6487-3762 {} |" ). format ( r , w , w , w , lgray , w )
    cetak ( "{} '------------------------------------ {} ------ - '" ). format ( r , w )
    cetak ( "{} [{} Halaman daftar: {} {}]" ). format ( r , w , rfindpage , r )
    lari ()
    
def  run ():
    coba :
        halaman  =  masukan ( " \ 033 [1; 31m [ \ 033 [1; 37mPage \ 033 [1; 31m] \ 033 [1; 37m>" )
        url  = ( "https://www.insecam.org/en/bycountry/IT/?page=" + str ( halaman ))
        cetak  ""
        res  =  permintaan . get ( url , headers = headers )
        findip  =  re . findAll ( 'http: // \ d + \ d + \ d + \ d +... \ d +' , res . teks )
        hitung  =  1
        untuk  _  di  findip :
             hasil  =  findip [ hitungan ]
             cetak ( "{} [{} {} {}]" ). format ( r , w , hasil , r )
             hitung  + =  1
    kecuali :
        cetak  ""
        print  r + "Makasi udh pake tools kami" + w